﻿using System.Text.RegularExpressions;
/* Вставить в Program.cs, чтобы проверить ответы.

string path = "C:\\Labs\\AllLabs\\LR5\\LR5\\AllValues.txt";

string[] input = File.ReadAllLines(path); //чтение массива строк
for (int i = 0; i < input.Length; ++i)
{
    Regex regex = new Regex();
    if (regex.IsMatch(input[i]))
    {
        Console.WriteLine(regex.Match(input[i]));

    }

}
*/